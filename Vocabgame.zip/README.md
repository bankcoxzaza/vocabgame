# vocabgame
การติดตั้งแอป Vocab Game

1. Install
ต้องทำการติดตั้ง Node.js ก่อน
จากนั้นติดตั้ง cordova ใช้คำสั่ง npm install -g cordova


npm install -g cordova


2. Build App
เริ่มต้นสร้างโปรเจ็คขึ้นมา โดย cd Myapp
จากนั้นให้เพิ่ม Android และทำการ build โปรแกรมโดยใช้คำสั่ง cordova build


cd myapp
cordova platform add android
cordova build


3. Start App
สุดท้าย ทดสอบรันโปรแกรม ด้วยคำสั่ง cordova run android หรือ cordova run browser


cordova run android
cordova run browser


4. Apk App

 

เมื่อ build เสร็จแล้วไฟล์ apk จะอยู่ใน Address ข้างล่าง


…\vocab\platforms\android\app\build\outputs\apk\debug\app-debug.apk




ชื่อสมาชิก
1.	นายณัฐวุฒิ   แสงพรหม รหัส 6010210453
2.	นายปานุวัฒน์   ศรีสุขแก้ว รหัส 6010210526
3.	นางสาวสาลิณี   ขวัญทองยิ้ม รหัส 6010210628
